<?php 
namespace App\Models;
defined('BASEPATH') OR exit('No direct script access allowed');

use \Illuminate\Database\Eloquent\Model as Eloquent;

class Products extends Eloquent{
	protected $table = 'potatoes';
    
}