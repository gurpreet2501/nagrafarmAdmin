<head>
	<title>Dashboard - Canvas Admin</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="">
	<meta name="author" content="" />
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets\css\custom.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets\css\bootstrap.min.css')?>">
</head>
