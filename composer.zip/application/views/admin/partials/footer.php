<footer id="footer">
	<ul class="nav pull-right">
		<li>
			Copyright &copy; 2013, Jumpstart Themes.
		</li>
	</ul>
</footer>
