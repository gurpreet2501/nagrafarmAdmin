    <?php $this->load->view('common/js') ?>
</body>
</html>