<div id="content">
	<div id="content-header">
		<h1><?= $heading ?></h1>
	</div> <!-- #content-header -->	

	<div id="content-container">
      <?= $output ?>
	</div> <!-- #content -->
</div>